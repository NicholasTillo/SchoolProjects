class Node():
    def __init__(self,data):
        self.data = data
        self.LeftChild = None
        self.RightChild = None
        self.height = 0
    

class BinarySearchTree():
    def __init__(self):
        self.root = None 



    def rec_insert(self, value, node):
        #If the node doesnt exist, create one and put it here
        if not node:
            node = Node(value)
            return node
        #if the node already exists, do nothing. 
        elif self.root.data == value:
            return 0

        #If the value is less than the current node, check left. 
        if node.data > value:
            tempVal = self.rec_insert(value, node.LeftChild);
            #If there is a value returned, set the child to be the new node
            if tempVal:
                    node.LeftChild = tempVal
        #If the value is greater than the current node, check right. 
        elif(node.data < value):
            tempVal = self.rec_insert(value, node.RightChild);
            #If there is a value returned, set the child to be the new node
            if tempVal:
                    node.RightChild = tempVal
    
    def rec_updateHeights(self, node):
        #If both children are there, gather both heights, and choose the highest.
        if node.LeftChild and node.RightChild:
            lc = self.rec_updateHeights(node.LeftChild) 
            rc = self.rec_updateHeights(node.RightChild)
            if lc > rc:
                node.height = lc + 1
            else:
                node.height = rc + 1
        #If there are no children, then the height is 0.
        elif not node.LeftChild and not node.RightChild:
            node.height = 0
        #If there is only one child, the height is that much plus 1
        elif not node.LeftChild:
            node.height = self.rec_updateHeights(node.RightChild) + 1
        elif not node.RightChild:
            node.height = self.rec_updateHeights(node.LeftChild)  + 1

        return node.height
        

    def insert(self, value):
        #Insert helper function
        #If there is no root, make the new node the root. 
        if not self.root:
            self.root= Node(value)
        #If we are inserting the root node, 
        elif self.root.data == value:
            print(self.root.data)
            return
        else:
            self.rec_insert(value, self.root)
        #After inserting, update all the heights. 
        self.rec_updateHeights(self.root)
        

    def get_total_height(self):
        #If the tree doesnt exist, the height total is zero, 
        if self.root == None:
            return 0
        else:
            #if not, get the total height 
            return self.rec_get_total_height(self.root)

    def rec_get_total_height(self,node):
        #If both nodes exist, the total height is the current node plus both its children. 
        if node.LeftChild and node.RightChild:
            return node.height + self.rec_get_total_height(node.LeftChild) + self.rec_get_total_height(node.RightChild)
        
        #If there are no children, return no heights. 
        elif not node.LeftChild and not node.RightChild:
            return 0
        
        #If the node only has 1 child, get the childs height plus the current nodes height. 
        elif not node.LeftChild:
            return self.rec_get_total_height(node.RightChild) + node.height
        elif not node.RightChild:
            return self.rec_get_total_height(node.LeftChild) + node.height



    def rec_save(self, node):
        #if the node exists, add its children and itself to the exit string, 
        if node:
            return str(node.data) + "(" +str(self.rec_save(node.LeftChild)) +":" + str(self.rec_save(node.RightChild) + ")")
        else:
            return ""
    def save(self):
        #preorder traversal, 
        R = ""
        R = self.rec_save(self.root)
        return R

    def restore(self, strings):
        #Get the string, and loop through all characters, If its a connecting character, push the contents to the tree, 
        # If its a number, combine the number to account for multiple digit numbers
        self.root = None
        value = ""
        for char in strings:
            if char == ":" or char == "(" or char == ")":
                if value == "":
                    continue
                else:
                    self.insert(int(value))
                    value = ""
            else:
                value += char
    def delete(self, value):
        #Helper function for the delete function 
        if not self.root:
            return
        #Start recursivly checking for the object to delete. 
        self.rec_delete(self.root, None, value)
        #After deleted, update the heights
        self.rec_updateHeights(self.root)


    
    def rec_delete(self, node, parent, value):
    #Recursivley look to delete a node. 
        #If the node desont exsists, return. 
        if not node:
            return
            #No find. 
        #If we find the node, delete the node. 
        elif node.data == value:
            #If it has 2 children. 
            if node.LeftChild and node.RightChild:
                tempNode = node.LeftChild
                #Search for the rightmost left subchild. 
                while tempNode.RightChild:
                    tempNode = tempNode.RightChild
                #Delete the node we swap with. 
                self.delete(tempNode.data)
                #Swap data, with the node. 
                node.data = tempNode.data

            #If there are 0 children 
            elif not node.LeftChild and not node.RightChild:
                #If its the root, just set it to none. 
                if node == self.root:
                    self.root == None
                #Make the parents child set to none.
                else:
                    if parent.LeftChild == node:
                        parent.LeftChild = None
                    else:
                        parent.RightChild = None
            #If its only a right child. 
            elif not node.LeftChild:
                #Root edge case
                if node == self.root:
                    self.root = node.RightChild
                #Set the paretns child to be the deleted nodes child
                elif parent.LeftChild == node:
                    parent.LeftChild = node.RightChild
                else:
                    parent.RightChild = node.RightChild
            #If its only a left child 
            elif not node.RightChild:
                #Root edge case
                if node == self.root:
                    self.root = node.LeftChid
                #Set the paretns child to be the deleted nodes child
                elif parent.LeftChild == node:
                    parent.LeftChild = node.LeftChild
                else:
                    parent.RightChild = node.LeftChild

            #Node is what we are looking for. 
        elif value < node.data:
            self.rec_delete(node.LeftChild,node, value)
        elif value > node.data:
            self.rec_delete(node.RightChild,node, value)



def main():
    binary  = BinarySearchTree()
    print(binary.get_total_height())
    binary.insert(5)
    binary.insert(6)
    binary.insert(3)
    binary.delete(5)
    binary.delete(10)
    binary.insert(19)
    binary.insert(20)
    binary.insert(22)
    binary.insert(21)
    binary.insert(23)
    print(binary.get_total_height()) 
    strs = binary.save()
    print(strs)
    newBin = BinarySearchTree()
    newBin.restore(strs)
    print(newBin.save())

main()



