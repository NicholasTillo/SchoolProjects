import re
from nltk.corpus import stopwords
import string



class AVLnode():
    def __init__(self,name):
        self.left = None
        self.right = None
        self.height = 0
        self.frequency = 1
        self.data = name
            

class AVLTreeMap():
    def __init__(self):
        self.root = None
    
    def parse_file(self,file):
        stop_words = set(stopwords.words('english'))
        with open(file, 'r') as input:
            content = input.readlines()
        preprocessed = []
        for line in content:
            line = line.strip().lower()
            #remove punctuation
            line = line.translate(str.maketrans('', '', string.punctuation))
            #remove stop words that care no specific meaning
            line = self.remove_stopwords(line,stop_words)
            #remove numbers
            line = re.sub('\d+','', line)
            #remove extra white space
            line = re.sub(' +', ' ', line)
            if line:
                preprocessed.extend(line.split(" "))
            print(" ".join(preprocessed))
        return preprocessed
    

    def remove_stopwords(self,text,stop_words):
        return " ".join([word for word in str(text).split() if word not in stop_words])
        

    def rec_computeheight(self, node):
        if node is None:
            return 0
        else:
            # Compute the height of each subtree
            lheight = self.rec_computeheight(node.left)
            rheight = self.rec_computeheight(node.right)
    
            # Use the larger one
            if lheight > rheight:
                return lheight+1
            else:
                return rheight+1
            
    def rec_print(self, node):
        #Fill the empty string with all the information about each node, then recurse down to cover all nodes. 
        if node:
            return str(node.data)+"\"" + str(node.frequency) +"\"" + "(" +str(self.rec_print(node.left)) +":" + str(self.rec_print(node.right) + ")")
        else:
            return ""
    def print(self):
        #preorder traversal,
        #Create an empty string to add everything to, 
        R = ""
        R = self.rec_print(self.root)
        return R
            
    def insert(self, value):
        #Helper function for recursive insert. 
        if not self.root:
            #If tree is empty, the new node is the root. 
            self.root = AVLnode(value)
        elif self.root.data == value:
            #If the root already exists, add frequency.
            self.root.frequency += 1
        else:
            self.root = self.rec_insert(self.root, value)


    def rec_insert(self, node, value):
        #If there is an empty space in the tree
        if not node:
            #Add the new node
            return AVLnode(value)
        #If the node already exists,     
        elif node.data == value:
            #Add frequency
            node.frequency += 1
            return node
        #If its less than the current node, check left
        elif value < node.data:
            node.left = self.rec_insert(node.left, value)
        else:
        #If its less than the current node, check right
            node.right = self.rec_insert(node.right, value)
        #access heights

        hL = self.rec_computeheight(node.left)
        hR = self.rec_computeheight(node.right)
        node.height = 1 + max(hL, hR)

        #Create balance factor
        balanceFactor = hR - hL
        #If the node is unbalanced, then try out the 4 cases
        #Left child on left unbalenced data

        if balanceFactor < -1 and value < node.left.data:
            retNode = self.rightRotate(node)
            return retNode
        
        
        # Right child on right data, 
        if balanceFactor > 1 and value > node.right.data:
            retNode = self.leftRotate(node)
            return retNode
        
        if balanceFactor < -1 and value > node.left.data:
            node.left = self.leftRotate(node.left)
            retNode = self.rightRotate(node)
            return retNode
        
        if balanceFactor > 1 and value < node.right.data:
            node.right = self.rightRotate(node.right)
            retNode = self.leftRotate(node)
            return retNode
        
        return node

    #Right Rotations
    def rightRotate(self, B):
        A = B.left
        Aright = A.right
        A.right = B
        B.left = Aright


        AlH = self.rec_computeheight(A.left)
        ArH = self.rec_computeheight(A.right)
        BlH = self.rec_computeheight(B.left)
        BrH = self.rec_computeheight(B.right)
        if AlH > ArH:
            A.height = 1 + AlH
        else:
            A.height = 1 + ArH
        if BlH > BrH:
            B.height = 1 + BlH
        else:
            B.height = 1 + BrH
        #Return the new rotated root. 
        return A

    def leftRotate(self, A):
        B = A.right
        Bleft = B.left
        B.left = A
        A.right = Bleft
        AlH = self.rec_computeheight(A.left)
        ArH = self.rec_computeheight(A.right)
        BlH = self.rec_computeheight(B.left)
        BrH = self.rec_computeheight(B.right)
        if AlH > ArH:
            A.height = 1 + AlH
        else:
            A.height = 1 + ArH
        if BlH > BrH:
            B.height = 1 + BlH
        else:
            B.height = 1 + BrH

        #Return the new rotated root. 
        return B
    
    def LoadFromFile(self, filepath):
        #import file,
        parseList = self.parse_file(filepath)
        #Push all the values in the parseList. 
        for val in parseList:
            self.insert(val)


def main():
    
    #Create empty tree
    avlTree = AVLTreeMap()
    avlTree.LoadFromFile("test.txt")
    #Print
    #Data is stored in the form of:
    #Node(LeftChild:RightChild)
    print(avlTree.print())

main()