
# DO NOT EDIT

# Assignment for 20njt4

from lib204 import wff
P, Q, R, S, T = map(wff.Variable, 'PQRST')
s1 = (~(~S|R)>>~T)
s2 = ((~T&R)>>S)
s3 = (((R|~S)>>~T)|T)
s4 = (~((~S>>~T)&(R>>~T))>>T)

s5 = ((~R>>(~T&Q))|~(~R|T))
s6 = (~((Q&T)|R)>>(~R|~T))