
# This is your unique solution file

from config import *
from lib204 import semantic_interface

# Assignment for 20njt4

# Note: All of these answers are almost certainly wrong

a2q12 = [ [s1], [s2], [s3,s4] ] #s3 and s4 are both tautologies

a2q13 = {
    S: True,
    R: False,
    T: True
}

a2s5nnf = [
    [((~R>>(~T&Q))|~(~R|T)), 'starting formula'],
    [((~~R|(~T&Q))|~(~R|T)), 'Replace Implication'],
    [((R|(~T&Q))|~(~R|T)), 'Double Negation'],
    [((R|(~T&Q))|(~~R&~T)), 'de Morgans'],
    [((R|(~T&Q))|(R&~T)), 'Double Negation'],

]

a2s6nnf = [
    [(~((Q&T)|R)>>(~R|~T)), 'starting formula'],
    [(~~((Q&T)|R)|(~R|~T)), 'Replace Implication'],
    [(((Q&T)|R)|(~R|~T)), 'Double Negation'],
]

a2s5cnf = [
    [((~R>>(~T&Q))|~(~R|T)), 'starting formula'],
    [((~~R|(~T&Q))|~(~R|T)), 'Replace Implication'],
    [((R|(~T&Q))|~(~R|T)), 'Double Negation'],
    [((R|(~T&Q))|(~~R&~T)), 'de Morgans'],
    [((R|(~T&Q))|(R&~T)), 'Double Negation'],
    [(((R|~T)&(R|Q))|(R&~T)), 'Distribute'],
    [((((R|~T)&(R|Q))|(R)) & (((R|~T)&(R|Q))|(~T))), 'Distribute'],
    [((R|~T|R)&(R|Q|R)) & (((R|~T|~T)&(R|Q|~T))), 'Distribute'],
    [((R|Q)&(R|~T)&(R|Q|~T)), 'Simplify'],
]

a2s6cnf = [
    [(~((Q&T)|R)>>(~R|~T)), 'starting formula'],
    [(~~((Q&T)|R)|(~R|~T)), 'Replace Implication'],
    [((Q&T)|R|~R|~T), 'Double Negation'],
    [(((Q|R)&(R|T))|(~R|~T)), 'Distribute'],
    [(((Q|R|~R)&(R|T|~R))|~T), 'Distribute'],
    [((Q|R|~R|~T)&(R|T|~R|~T)), 'Distribute'],
]

a2s5tseitin = semantic_interface.Encoding()
# Fill in the Tseitin steps and finalize
x1 = a2s5tseitin.tseitin(Q & T, 'x1') # just an example
x2 = a2s5tseitin.tseitin(R | x1, 'x2')
x3 = a2s5tseitin.tseitin(~x2, 'x3')
x4 = a2s5tseitin.tseitin(~R, 'x4')
x5 = a2s5tseitin.tseitin(~T, 'x5')
x6 = a2s5tseitin.tseitin(x4|x5, 'x6')
x7 = a2s5tseitin.tseitin(x3 >> x6, 'x7')
a2s5tseitin.finalize(x7) # make sure you update the variable!

a2s6tseitin = semantic_interface.Encoding()
# Fill in the Tseitin steps and finalize
x1 = a2s5tseitin.tseitin(~R, 'x1') # just an example
x2 = a2s5tseitin.tseitin(x1 | T, 'x2')
x3 = a2s5tseitin.tseitin(~x2, 'x3')
x4 = a2s5tseitin.tseitin(~T, 'x4')
x5 = a2s5tseitin.tseitin(x4 & Q, 'x5')
x6 = a2s5tseitin.tseitin(x3 | x5, 'x6')
x7 = a2s5tseitin.tseitin(~R, 'x7')
x8 = a2s5tseitin.tseitin(x7 >> x6, 'x8')
a2s5tseitin.finalize(x8) # make sure you update the variable!
